package com.example.fingerprintanimation

import android.content.Context
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.lifecycle.lifecycleScope
import kotlin.math.min

private val NeonRed = Color(0xFFFF1744)
private val Background = Color(0xFF050505)
private val Panel = Color(0xFF141414)
private val Muted = Color(0xFFBDBDBD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("fingerprint_animation", Context.MODE_PRIVATE)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = NeonRed,
                    background = Background,
                    surface = Panel,
                    onPrimary = Color.White,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                var showSettings by remember { mutableStateOf(false) }
                var selectedMode by remember {
                    mutableStateOf(prefs.getString("mode", "Manual app launch") ?: "Manual app launch")
                }
                var soundOn by remember { mutableStateOf(prefs.getBoolean("sound", true)) }
                var vibrationOn by remember { mutableStateOf(prefs.getBoolean("vibration", true)) }
                var autoStart by remember { mutableStateOf(prefs.getBoolean("autostart", false)) }
                var speed by remember { mutableFloatStateOf(prefs.getFloat("speed", 1f)) }
                // Position is a vertical offset in dp; positive values move the sensor toward the bottom.
                var sensorPosition by remember { mutableFloatStateOf(prefs.getFloat("sensor_position", 115f)) }
                var sensorSize by remember { mutableFloatStateOf(prefs.getFloat("sensor_size", 236f)) }
                var customPin by remember { mutableStateOf(prefs.getString("pin", "") ?: "") }
                var backgroundChoice by remember { mutableStateOf(prefs.getString("background", "Black") ?: "Black") }
                var scanning by remember { mutableStateOf(false) }
                var unlocked by remember { mutableStateOf(false) }
                var showPinDialog by remember { mutableStateOf(false) }
                var enteredPin by remember { mutableStateOf("") }
                var pinError by remember { mutableStateOf(false) }

                if (showSettings) {
                    SettingsScreen(
                        selectedMode = selectedMode,
                        onModeChange = {
                            selectedMode = it
                            prefs.edit().putString("mode", it).apply()
                        },
                        soundOn = soundOn,
                        onSoundChange = { soundOn = it; prefs.edit().putBoolean("sound", it).apply() },
                        vibrationOn = vibrationOn,
                        onVibrationChange = { vibrationOn = it; prefs.edit().putBoolean("vibration", it).apply() },
                        autoStart = autoStart,
                        onAutoStartChange = { autoStart = it; prefs.edit().putBoolean("autostart", it).apply() },
                        speed = speed,
                        onSpeedChange = { speed = it; prefs.edit().putFloat("speed", it).apply() },
                        sensorPosition = sensorPosition,
                        onSensorPositionChange = { sensorPosition = it; prefs.edit().putFloat("sensor_position", it).apply() },
                        sensorSize = sensorSize,
                        onSensorSizeChange = { sensorSize = it; prefs.edit().putFloat("sensor_size", it).apply() },
                        onResetSensorLayout = { sensorPosition = 115f; sensorSize = 236f; prefs.edit().putFloat("sensor_position", 115f).putFloat("sensor_size", 236f).apply() },
                        backgroundChoice = backgroundChoice,
                        onBackgroundChange = { backgroundChoice = it; prefs.edit().putString("background", it).apply() },
                        customPin = customPin,
                        onPinSave = { customPin = it; prefs.edit().putString("pin", it).apply() },
                        onBack = { showSettings = false }
                    )
                } else {
                    val pageBackground = when (backgroundChoice) {
                        "Deep red" -> Color(0xFF190006)
                        "Charcoal" -> Color(0xFF171717)
                        else -> Background
                    }
                    Box(
                        modifier = Modifier.fillMaxSize().background(pageBackground).padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text("FINGERPRINT", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 2.5.sp)
                                    Text("NEON BIOMETRIC EXPERIENCE", color = NeonRed, fontSize = 10.sp, letterSpacing = 1.5.sp)
                                }
                                TextButton(onClick = { showSettings = true }) { Text("SETTINGS", color = NeonRed) }
                            }
                            Spacer(Modifier.weight(1f))
                            if (unlocked) {
                                Text("ACCESS GRANTED", color = NeonRed, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(10.dp))
                                Text("Animation complete — this is not real biometric authentication.", color = Muted, fontSize = 13.sp)
                                Spacer(Modifier.height(16.dp))
                                Button(onClick = { unlocked = false; scanning = false }, colors = ButtonDefaults.buttonColors(containerColor = NeonRed)) { Text("Lock animation again") }
                            } else {
                                Text(
                                    when {
                                        scanning -> "SCANNING YOUR FINGER"
                                        selectedMode == "Simulated lock-screen experience" -> "SIMULATED LOCK SCREEN"
                                        selectedMode == "Screen wake" -> "SCREEN-WAKE DEMO"
                                        else -> "TOUCH TO START SCAN"
                                    },
                                    color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                Text("Place your finger over the glowing sensor", color = Muted, fontSize = 12.sp)
                                Spacer(Modifier.height(8.dp))
                                FingerprintScanner(
                                    scanning = scanning,
                                    speed = speed,
                                    sensorSize = sensorSize,
                                    modifier = Modifier.offset(y = sensorPosition.dp),
                                    onTap = {
                                        if (customPin.isNotBlank()) {
                                            showPinDialog = true
                                        } else {
                                            startScan(
                                                onStart = { scanning = true },
                                                onDone = { scanning = false; unlocked = true },
                                                activity = this@MainActivity,
                                                soundOn = soundOn,
                                                vibrationOn = vibrationOn,
                                                speed = speed
                                            )
                                        }
                                    }
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    if (scanning) "Reading animated scan…" else "TAP THE SENSOR TO PLAY",
                                    color = if (scanning) Color(0xFFFF8296) else Muted,
                                    fontSize = 11.sp,
                                    letterSpacing = 1.2.sp
                                )
                                Spacer(Modifier.height(14.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.background(Color(0xFF16070B), RoundedCornerShape(50)).padding(horizontal = 13.dp, vertical = 8.dp)
                                ) {
                                    Box(Modifier.size(6.dp).background(NeonRed, CircleShape))
                                    Text("SIMULATION ONLY • NOT ANDROID SECURITY", color = Color(0xFFFF8A9D), fontSize = 9.sp, letterSpacing = 0.6.sp)
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            Text("Immersive visual effects  •  Settings & controls", color = Muted, fontSize = 11.sp)
                        }
                    }
                }

                if (showPinDialog) {
                    AlertDialog(
                        onDismissRequest = { showPinDialog = false; enteredPin = ""; pinError = false },
                        title = { Text("App PIN") },
                        text = {
                            Column {
                                Text("Enter the demo PIN to continue. This PIN only gates this app; it is not your phone PIN.")
                                Spacer(Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = enteredPin,
                                    onValueChange = { enteredPin = it; pinError = false },
                                    label = { Text("PIN") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true
                                )
                                if (pinError) Text("PIN does not match.", color = NeonRed)
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                if (enteredPin == customPin) {
                                    showPinDialog = false
                                    enteredPin = ""
                                    startScan(
                                        onStart = { scanning = true },
                                        onDone = { scanning = false; unlocked = true },
                                        activity = this@MainActivity,
                                        soundOn = soundOn,
                                        vibrationOn = vibrationOn,
                                        speed = speed
                                    )
                                } else pinError = true
                            }) { Text("Continue") }
                        },
                        dismissButton = {
                            TextButton(onClick = { showPinDialog = false; enteredPin = "" }) { Text("Cancel") }
                        }
                    )
                }
            }
        }
    }
}

private fun startScan(
    onStart: () -> Unit,
    onDone: () -> Unit,
    activity: ComponentActivity,
    soundOn: Boolean,
    vibrationOn: Boolean,
    speed: Float
) {
    onStart()
    if (soundOn) {
        try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70).startTone(ToneGenerator.TONE_PROP_BEEP, 140) } catch (_: Exception) {}
    }
    if (vibrationOn) {
        try {
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
                activity.getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                activity.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator.vibrate(VibrationEffect.createOneShot(90, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }
    activity.lifecycleScope.launchWhenStarted {
        delay((1800L / speed.coerceIn(0.5f, 2f)).toLong())
        onDone()
    }
}

@Composable
private fun FingerprintScanner(scanning: Boolean, speed: Float, sensorSize: Float, modifier: Modifier = Modifier, onTap: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "scanner")
    val pulse by transition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.045f,
        animationSpec = infiniteRepeatable(
            animation = tween((1050 / speed.coerceIn(0.5f, 2f)).toInt(), easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val sweep by transition.animateFloat(
        initialValue = -0.82f,
        targetValue = 0.82f,
        animationSpec = infiniteRepeatable(
            animation = tween((1450 / speed.coerceIn(0.5f, 2f)).toInt(), easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sweep"
    )
    Box(
        modifier = modifier.size(sensorSize.coerceIn(140f, 320f).dp).clickable { if (!scanning) onTap() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val unit = min(size.width, size.height)
            val maxR = unit * 0.455f
            val glowRadius = maxR * 1.08f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x66FF1744), Color(0x22FF1744), Color.Transparent),
                    center = center,
                    radius = glowRadius
                ),
                radius = glowRadius,
                center = center
            )
            // Fine outer HUD rings create depth without overwhelming the fingerprint.
            drawCircle(Color(0x55FF1744), maxR * 1.02f, center, style = Stroke(width = 1.2f))
            drawCircle(Color(0x33FF7088), maxR * 0.91f, center, style = Stroke(width = 1f))
            for (i in 0..3) {
                val radius = maxR * (0.48f + i * 0.165f) * if (scanning) pulse else 1f
                drawCircle(
                    brush = Brush.sweepGradient(
                        colors = listOf(Color.Transparent, Color(0xFFFF1744), Color(0xFFFF8A65), Color.Transparent),
                        center = center
                    ),
                    radius = radius,
                    center = center,
                    style = Stroke(width = if (scanning) 2.4f else 1.25f)
                )
            }
            // Short calibrated ticks give the sensor a premium sci-fi interface look.
            for (i in 0 until 48) {
                val angle = Math.toRadians(i * 7.5)
                val inner = maxR * if (i % 4 == 0) 0.88f else 0.92f
                val outer = maxR * 0.97f
                val a = Offset(center.x + kotlin.math.cos(angle).toFloat() * inner, center.y + kotlin.math.sin(angle).toFloat() * inner)
                val b = Offset(center.x + kotlin.math.cos(angle).toFloat() * outer, center.y + kotlin.math.sin(angle).toFloat() * outer)
                drawLine(Color(0xAAFF536B), a, b, strokeWidth = if (i % 4 == 0) 1.8f else 0.8f, cap = StrokeCap.Round)
            }
            // Fingerprint ridge artwork, layered in warm neon with rounded ends.
            val fpR = maxR * 0.56f
            for (i in 0..7) {
                val inset = i * fpR * 0.105f
                val left = center.x - fpR + inset
                val top = center.y - fpR + inset * 0.82f
                val diameter = (fpR - inset) * 2f
                if (diameter > 3f) {
                    drawArc(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFFFF6B82), Color(0xFFFF1744), Color(0xFFFFA06A)),
                            start = Offset(left, top),
                            end = Offset(left + diameter, top + diameter)
                        ),
                        startAngle = 202f + i * 3.5f,
                        sweepAngle = 252f - i * 10.5f,
                        useCenter = false,
                        topLeft = Offset(left, top),
                        size = Size(diameter, diameter),
                        style = Stroke(width = if (scanning) 3.2f else 2.6f, cap = StrokeCap.Round)
                    )
                }
            }
            // Animated scan beam and subtle beam glow.
            val beamY = center.y + sweep * maxR * 0.72f
            drawLine(Color(0x33FF1744), Offset(center.x - maxR * 0.73f, beamY), Offset(center.x + maxR * 0.73f, beamY), strokeWidth = 9f, cap = StrokeCap.Round)
            drawLine(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, Color(0xFFFFA0B0), Color(0xFFFF1744), Color(0xFFFFA0B0), Color.Transparent), startX = center.x - maxR * 0.74f, endX = center.x + maxR * 0.74f),
                start = Offset(center.x - maxR * 0.74f, beamY),
                end = Offset(center.x + maxR * 0.74f, beamY),
                strokeWidth = if (scanning) 2.6f else 1.2f,
                cap = StrokeCap.Round
            )
            drawCircle(Color(0xFFFFCCD4).copy(alpha = if (scanning) 0.95f else 0.55f), radius = 3f, center = center)
        }
    }
}

@Composable
private fun SettingsScreen(
    selectedMode: String,
    onModeChange: (String) -> Unit,
    soundOn: Boolean,
    onSoundChange: (Boolean) -> Unit,
    vibrationOn: Boolean,
    onVibrationChange: (Boolean) -> Unit,
    autoStart: Boolean,
    onAutoStartChange: (Boolean) -> Unit,
    speed: Float,
    onSpeedChange: (Float) -> Unit,
    sensorPosition: Float,
    onSensorPositionChange: (Float) -> Unit,
    sensorSize: Float,
    onSensorSizeChange: (Float) -> Unit,
    onResetSensorLayout: () -> Unit,
    backgroundChoice: String,
    onBackgroundChange: (String) -> Unit,
    customPin: String,
    onPinSave: (String) -> Unit,
    onBack: () -> Unit
) {
    var pinDraft by remember(customPin) { mutableStateOf(customPin) }
    Column(
        Modifier.fillMaxSize().background(Background).verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("SETTINGS", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onBack) { Text("DONE", color = NeonRed) }
        }
        Text("Select one mode at a time. Screen-wake mode is best-effort and cannot replace Android's secure lock screen.", color = Muted, fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(14.dp)) {
                Text("Unlock experience", color = NeonRed, fontWeight = FontWeight.Bold)
                listOf("Manual app launch", "Screen wake", "Simulated lock-screen experience").forEach { mode ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selectedMode == mode, onClick = { onModeChange(mode) }, colors = RadioButtonDefaults.colors(selectedColor = NeonRed))
                        Column(Modifier.weight(1f)) {
                            Text(mode, color = Color.White)
                            if (mode == "Screen wake") Text("Best effort only; Android/OEM may restrict it.", color = Muted, fontSize = 11.sp)
                            if (mode == "Simulated lock-screen experience") Text("Runs inside this app, not over system security.", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Effects", color = NeonRed, fontWeight = FontWeight.Bold)
                SettingSwitch("Sound effects", soundOn, onSoundChange)
                SettingSwitch("Vibration", vibrationOn, onVibrationChange)
                SettingSwitch("Auto-start where supported", autoStart, onAutoStartChange)
                Text("Auto-start is a saved preference in this starter. Background launch requires additional platform-compliant implementation and may not be allowed.", color = Muted, fontSize = 11.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Fingerprint area layout", color = NeonRed, fontWeight = FontWeight.Bold)
                Text("Vertical position: ${sensorPosition.toInt()} dp", color = Muted)
                Slider(value = sensorPosition, onValueChange = onSensorPositionChange, valueRange = -180f..220f, colors = SliderDefaults.colors(thumbColor = NeonRed, activeTrackColor = NeonRed))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Higher", color = Muted, fontSize = 11.sp)
                    Text("Lower", color = Muted, fontSize = 11.sp)
                }
                Text("Area size: ${sensorSize.toInt()} dp", color = Muted)
                Slider(value = sensorSize, onValueChange = onSensorSizeChange, valueRange = 140f..320f, colors = SliderDefaults.colors(thumbColor = NeonRed, activeTrackColor = NeonRed))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Compact", color = Muted, fontSize = 11.sp)
                    Text("Large", color = Muted, fontSize = 11.sp)
                }
                OutlinedButton(onClick = onResetSensorLayout, modifier = Modifier.fillMaxWidth()) { Text("Reset layout (default lower position)") }
                Text("Your layout is saved automatically on this phone. Some screen sizes may limit how far the area can move.", color = Muted, fontSize = 11.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Animation speed", color = NeonRed, fontWeight = FontWeight.Bold)
                Text(when { speed < 0.8f -> "Slow"; speed > 1.3f -> "Fast"; else -> "Normal" }, color = Muted)
                Slider(value = speed, onValueChange = onSpeedChange, valueRange = 0.5f..2f, colors = SliderDefaults.colors(thumbColor = NeonRed, activeTrackColor = NeonRed))
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Background", color = NeonRed, fontWeight = FontWeight.Bold)
                listOf("Black", "Deep red", "Charcoal").forEach { bg ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = backgroundChoice == bg, onClick = { onBackgroundChange(bg) }, colors = RadioButtonDefaults.colors(selectedColor = NeonRed))
                        Text(bg, color = Color.White)
                    }
                }
                Text("Custom image picker is not included in this starter; these are built-in background presets.", color = Muted, fontSize = 11.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Optional in-app PIN", color = NeonRed, fontWeight = FontWeight.Bold)
                Text("Demo only. This is not Android's screen lock or biometric authentication.", color = Muted, fontSize = 12.sp)
                OutlinedTextField(value = pinDraft, onValueChange = { pinDraft = it }, label = { Text("Set app PIN (blank disables)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                Button(onClick = { onPinSave(pinDraft) }, colors = ButtonDefaults.buttonColors(containerColor = NeonRed)) { Text("Save PIN") }
            }
        }
        Text("Neon red • Adjustable scanner position and size • Simulated animation only", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White)
        Switch(checked = checked, onCheckedChange = onCheckedChange, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = NeonRed))
    }
}
